# MVH4CKSBot-
MVH4CKS Ultimate Clashbot
Last version 5.5.8

## Contacts
Gmail: MVH4CKS@gmail.com
Kik: Disney_mike_wazowski

### Reference
For your convenience, and referring to pushbullet's document:
https://docs.pushbullet.com/

### Credit
Much thanks to: the original creators of the original bot at brokenbot.org, gamebot.org, clashbot.org, cool7su, maxcom, msh2050, usabug, cmestres, samkhowaja and anyone else who I missed but has contributed to this great project!

Original source from which this is modified (project originally started at gamebot.org):
Modification of v5.8 of bot originally available from http://clashbot.org/forums/index.php?/topic/1010-flawless-clashbot-release-58-recommended/

Clash of Clans is a Registered Trademark of SuperCell. This project is not affiliated with SuperCell or any of its affiliates in any way. Project is available without warranty express or implied.

